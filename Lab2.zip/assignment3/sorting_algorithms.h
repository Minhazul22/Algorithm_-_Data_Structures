
#ifndef SORTING_ALGORITHMS_H
#define SORTING_ALGORITHMS_H

// Function prototypes for sorting algorithms
void insertionSort(int arr[], int size);
void selectionSort(int arr[], int size);
void shellSort(int arr[], int size);
void mergeSort(int arr[], int left, int right);
void bottomUpMergeSort(int arr[], int size);
void quickSort(int arr[], int low, int high);

// Global counters for comparisons and exchanges
extern unsigned long long comparisonCount;
extern unsigned long long exchangeCount;

// Functions to reset and retrieve counters
void resetCounters();
unsigned long long getComparisonCount();
unsigned long long getExchangeCount();

#endif // SORTING_ALGORITHMS_H
