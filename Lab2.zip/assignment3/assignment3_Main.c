
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "sorting_algorithms.h"




#define MAX_SIZE 20

void initArray(int arr[], int k) {
    // Handle the case when k > MAX_SIZE
    if (k > MAX_SIZE) {
        k = MAX_SIZE;  // Limit k to MAX_SIZE
    }

    // Fill the array with unsorted values initially
    for (int i = 0; i < MAX_SIZE; i++) {
        arr[i] = rand() % MAX_SIZE; // for unsorted values
    }

    // Sort the beginning of the array with values from 1 to MAX_SIZE - k
    for (int i = 0; i < MAX_SIZE - k; i++) {
        arr[i] = i + 1;
    }
}

int main() {
    int intArray[MAX_SIZE];
    int k = 7;

    // Seed the random number generator
    srand(time(NULL));

    // Initialize the integer array
    initArray(intArray, k);

    printf("Initialized array with sorted and unsorted elements:\n");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%d ", intArray[i]);
    }
    printf("\n");

    int choice;

    // Ask the user for their choice of sorting algorithm
    printf("Choose a sorting algorithm:\n");
    printf("1. Insertion Sort\n");
    printf("2. Selection Sort\n");
    printf("3. Shell Sort\n");
    printf("4. Merge Sort\n");
    printf("5. Bottom-up Merge Sort\n");
    printf("6. Quick Sort\n");
    printf("Enter the number corresponding to your choice: ");
    scanf("%d", &choice);

    // Perform the sorting based on the user's choice
    switch (choice) {
    case 1:
        insertionSort(intArray, MAX_SIZE);
        break;
    case 2:
        selectionSort(intArray, MAX_SIZE);
        break;
    case 3:
        shellSort(intArray, MAX_SIZE);
        break;
    case 4:
        mergeSort(intArray, 0, MAX_SIZE - 1);
        break;
    case 5:
        bottomUpMergeSort(intArray, MAX_SIZE);
        break;
    case 6:
        quickSort(intArray, 0, MAX_SIZE - 1);
        break;
    default:
        printf("Invalid choice.\n");
        break;
    }

    // Print the sorted array
    printf("Sorted array:\n");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%d ", intArray[i]);
    }

    // Retrieve and display the comparison and exchange counts
    printf("\nComparisons: %llu\n", getComparisonCount());
    printf("Exchanges: %llu\n", getExchangeCount());

    return 0;
}
