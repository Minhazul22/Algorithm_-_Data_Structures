
#include "sorting_algorithms.h"
#include <stddef.h>
#define NULL 0

// Global counters for comparisons and exchanges
unsigned long long comparisonCount = 0;
unsigned long long exchangeCount = 0;

// Function to reset counters
void resetCounters() {
    comparisonCount = 0;
    exchangeCount = 0;
}

// Function to get comparison count
unsigned long long getComparisonCount() {
    return comparisonCount;
}

// Function to get exchange count
unsigned long long getExchangeCount() {
    return exchangeCount;
}

// a) Insertion Sort
void insertionSort(int arr[], int size) {
    resetCounters(); // Reset counters before sorting
    int i, key, j;
    for (i = 1; i < size; i++) {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
            exchangeCount++; // Increment exchange count
            comparisonCount++; // Increment comparison count
        }
        arr[j + 1] = key;
    }
}

// b) Selection Sort
void selectionSort(int arr[], int size) {
    resetCounters(); // Reset counters before sorting
    int i, j, minIdx;
    for (i = 0; i < size - 1; i++) {
        minIdx = i;
        for (j = i + 1; j < size; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
                comparisonCount++; // Increment comparison count
            }
        }
        int temp = arr[i];
        arr[i] = arr[minIdx];
        arr[minIdx] = temp;
        exchangeCount++; // Increment exchange count
    }
}

// c) Shell Sort
void shellSort(int arr[], int size) {
    resetCounters(); // Reset counters before sorting
    int gap, i, j, temp;
    for (gap = size / 2; gap > 0; gap /= 2) {
        for (i = gap; i < size; i++) {
            temp = arr[i];
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) {
                arr[j] = arr[j - gap];
                exchangeCount++; // Increment exchange count
                comparisonCount++; // Increment comparison count
            }
            arr[j] = temp;
        }
    }
}

// d) Merge Sort
// Merge Sort
void merge(int arr[], int left, int middle, int right);

void mergeSort(int arr[], int left, int right) {
    if (left < right) {
        int middle = left + (right - left) / 2;
        mergeSort(arr, left, middle);
        mergeSort(arr, middle + 1, right);
        merge(arr, left, middle, right);
    }
}

void merge(int arr[], int left, int middle, int right) {
    int n1 = middle - left + 1;
    int n2 = right - middle;

    int L[n1], R[n2];

    for (int i = 0; i < n1; i++) {
        L[i] = arr[left + i];
    }
    for (int j = 0; j < n2; j++) {
        R[j] = arr[middle + 1 + j];
    }

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        comparisonCount++;
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
        exchangeCount++;
    }

    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
        exchangeCount++;
    }
}



// e) Bottom-up Merge Sort
void bottomUpMergeSort(int arr[], int size) {
    resetCounters(); // Reset counters before sorting
    for (int currSize = 1; currSize <= size - 1; currSize = 2 * currSize) {
        for (int left = 0; left < size - 1; left += 2 * currSize) {
            int middle = (left + currSize - 1 < size - 1) ? (left + currSize - 1) : (size - 1);
            int right = (left + 2 * currSize - 1 < size - 1) ? (left + 2 * currSize - 1) : (size - 1);
            merge(arr, left, middle, right);
        }
    }
}

// f) Quick Sort
int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            exchangeCount++; // Increment exchange count
        }
        comparisonCount++; // Increment comparison count
    }

    int temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;
    exchangeCount++; // Increment exchange count

    return (i + 1);
}

void quickSort(int arr[], int low, int high) {
    //resetCounters(); // Reset counters before sorting
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
