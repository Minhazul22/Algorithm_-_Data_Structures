// updated_program.c
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "sorting_algorithms.h"

#define MAX_SIZE 50000
#define MAX_RUN_TIME 300  // 5 minutes in seconds

void initArray(int arr[], int k);

void measureSortingPerformanceForMain(int k) {
    int intArray[MAX_SIZE];

    // Seed the random number generator
    srand(time(NULL));

    // Initialize the integer array using initArray from Assignment 1
    initArray(intArray, k);

    printf("\nInitialized array with sorted and unsorted elements (k = %d):\n", k);
    // Print the array if needed for verification
    // for (int i = 0; i < MAX_SIZE; i++) {
    //     printf("%d ", intArray[i]);
    // }

    clock_t start, end;
    double cpu_time_used;

    // Measure the time for Selection Sort
    start = clock();
    selectionSort(intArray, MAX_SIZE);
    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Selection Sort for k = %d took %f seconds.\n", k, cpu_time_used);

    // Reset the array
    initArray(intArray, k);

    // Measure the time for Merge Sort
    start = clock();
    mergeSort(intArray, 0, MAX_SIZE - 1);
    end = clock();
    cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Merge Sort for k = %d took %f seconds.\n", k, cpu_time_used);
}
