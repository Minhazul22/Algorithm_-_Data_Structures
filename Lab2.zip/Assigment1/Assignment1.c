#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_SIZE 20

void initArray(int arr[], int k) {
    // Handle the case when k > MAX_SIZE
    if (k > MAX_SIZE) {
        k = MAX_SIZE;  // Limit k to MAX_SIZE
    }

    // Fill the array with unsorted values initially
    for (int i = 0; i < MAX_SIZE; i++) {
        arr[i] = rand() % MAX_SIZE; // for unsorted values
    }

    // Sort the beginning of the array with values from 1 to MAX_SIZE - k
    for (int i = 0; i < MAX_SIZE - k; i++) {
        arr[i] = i + 1;
    }
}

int main() {
    int intArray[MAX_SIZE];
    int k = 7; //desired number of unsorted elements

    // Seed the random number generator
    srand(time(NULL));

    // Initialize the integer array
    initArray(intArray, k);

    printf("Initialized array with sorted and unsorted elements:\n");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%d ", intArray[i]);
    }

    return 0;
}
