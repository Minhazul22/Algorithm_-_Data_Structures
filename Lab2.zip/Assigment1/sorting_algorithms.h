#ifndef SORTING_ALGORITHMS_H
#define SORTING_ALGORITHMS_H

// Function prototypes for sorting algorithms

void insertionSort(int arr[], int size);
void selectionSort(int arr[], int size);
void shellSort(int arr[], int size);
void mergeSort(int arr[], int left, int right);
void bottomUpMergeSort(int arr[], int size);
void quickSort(int arr[], int low, int high);

#endif // SORTING_ALGORITHMS_H

