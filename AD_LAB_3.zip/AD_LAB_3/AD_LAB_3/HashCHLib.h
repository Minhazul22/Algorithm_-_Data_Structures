#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Macros
#define MAX_ARRAY 50
#define MAX_STRING 30
#define MAX_LINE 100

// Data type for chained hashing
typedef struct sElementCH {
    int key;
    char value[MAX_STRING];
    struct sElementCH* next;  // Pointer to the next element in the chain
} sElementCH;

/*
Function inserts a new element into the chained hash table or overwrites the value if the key already exists.

Input parameters:
hashtableCH: Chained hash table.
key: The key to be inserted.
value: The value corresponding to the key.

Return value:
Number of collisions when inserting the key-value pair.
*/
int putCH(sElementCH* hashtableCH[MAX_ARRAY], int key, char value[MAX_STRING]);

/*
Function searches for the key-value pair in the chained hash table.

Input parameters:
hashtableCH: Chained hash table.
key: The key to be searched.

Return value:
Pointer to the value corresponding to the key, or NULL if the key is not found.
*/
char* getCH(sElementCH* hashtableCH[MAX_ARRAY], int key);

/*
Function deletes the key-value pair from the chained hash table if it exists.

Input parameters:this is
hashtableCH: Chained hash table.
key: The key to be deleted.

Return value:
None.
*/
void deleteCH(sElementCH* hashtableCH[MAX_ARRAY], int key);

/*
Function prints the chained hash table on the console.

Input parameters:
hashtableCH: Chained hash table.

Return value:
None.
*/
void printHashTableCH(sElementCH* hashtableCH[MAX_ARRAY]);

/*
Function reads key-value pairs from a csv-file and stores these pairs in a chained hash table.

Input parameters:
fp: File pointer to the csv-file containing key-value pairs.
hashtableCH: Chained hash table.

Return value:
None.
*/
void readCSVCH(FILE* fP, sElementCH* hashtableCH[MAX_ARRAY]);
