#pragma once
#include <math.h> // necessary header for modf
#include "HashAHLib.h"

/*
Function reads an integer value safely from the keyboard.

Return value:
Read integer value
*/
int readInt() {
	int number, test = 0;
	do {
		test = scanf_s("%d", &number);
		if (test != 1) {
			while (getchar() != '\n');
			printf("Wrong input. Try again.\n");
		}
		else
			return number;
	} while (1);
}

/*
Function calculates the hash value for the passed key.

Input parameters:
key: The integer for which the hash value should be calculated.

Return value:
Calculated hash value for parameter key.

//Todo: Assignment 2, think about other options for calculating the hash value*/
int hashing(int key) {
	return key % MAX_ARRAY;
}
//Assignment 2
//multiplication
unsigned long multiplicationHashing(int key) {
	// Multiplication hashing parameters
	double A = 0.6180339887;  // Constant between 0 and 1
	double fracPart = modf(A * key, &A);
	return (unsigned long)(MAX_ARRAY * fracPart);
}

//djb2
unsigned long djb2Hashing(int key) {
	unsigned long hash = 5381;
	int c;

	while (c = key % 10) {
		hash = ((hash << 5) + hash) + c; // DJB2 hash function
		key /= 10;
	}

	return hash;
}

//xor
unsigned long xorHashing(int key) {
	unsigned long hash = 0;
	while (key > 0) {
		hash ^= (key & 0xFF);
		key >>= 8;
	}
	return hash;
}





/**********************************************************************************************************************
Prototypes for address hashing
**********************************************************************************************************************/
/*
Function creates a new entry in the hash table or if the key already exists overwrites the value with the passed value.

Input parameters:
hashtableAH: Function gets a hash table.
key: The key that should be inserted.
value: The value for the key that should be inserted.

Return value:
Function returns the number of collisions when inserting the key-value pair.
*/


// Assignment 1.1
int putAH(sElementAH hashtableAH[MAX_ARRAY], int key, char value[MAX_STRING]) {
	int index = hashing(key);

	// Check for collision
	int collisions = 0;
	while (hashtableAH[index].key != -1) {
		if (hashtableAH[index].key == key) {
			// Key already exists, overwrite the value
			strcpy_s(hashtableAH[index].value, MAX_STRING, value);
			return collisions;
		}
		// Linear probing for collision resolution
		index = (index + 1) % MAX_ARRAY;
		collisions++;

		// If the entire table is probed and no open slot is found, return
		if (collisions == MAX_ARRAY) {
			printf("Hash table is full. Cannot insert key %d.\n", key);
			return collisions;
		}
	}

	// Insert the new key-value pair
	hashtableAH[index].key = key;
	strcpy_s(hashtableAH[index].value, MAX_STRING, value);

	return collisions;
}


/*
Function searches for the key-value pair in the hash table having the passed key.

Input parameters:
hashtableAH: Function gets a hash table.
key: The key that should be searched for in the hash table.

Return value:
Function returns the value of entry with the given key or NULL if the key does not exist in the hash table.
*/

//assignment1.2
char* getAH(sElementAH hashtableAH[MAX_ARRAY], int key) {
	int index = hashing(key);

	// Search for the key
	while (hashtableAH[index].key != -1) {
		if (hashtableAH[index].key == key) {
			// Key found, return the value
			return hashtableAH[index].value;
		}
		// Linear probing for collision resolution
		index = (index + 1) % MAX_ARRAY;
	}

	// Key not found
	return NULL;
}

//assignment1.3
void deleteAH(sElementAH hashtableAH[MAX_ARRAY], int key) {
	int index = hashing(key);

	// Search for the key
	while (hashtableAH[index].key != -1) {
		if (hashtableAH[index].key == key) {
			// Key found, delete the entry
			hashtableAH[index].key = -1;
			strcpy_s(hashtableAH[index].value, MAX_STRING, "");
			return;
		}
		// Linear probing for collision resolution
		index = (index + 1) % MAX_ARRAY;
	}

	// Key not found, do nothing
}

//assignment1.4
void printHashTableAH(sElementAH hashtableAH[MAX_ARRAY]) {
	printf("Hash Table:\n");
	printf("Index   Key     Value\n");
	for (int i = 0; i < MAX_ARRAY; i++) {
		printf("%-8d%-8d", i, hashtableAH[i].key);
		if (hashtableAH[i].key == -1) {
			printf("empty\n");
		}
		else {
			printf("%s\n", hashtableAH[i].value);
		}
	}
	printf("\n");
}

void readCSVAH(FILE* fP, sElementAH hashtableAH[MAX_ARRAY]) {
	int number = 0;
	char buffer[MAX_LINE];
	char* field;
	char* nextToken = NULL;
	int key;
	char string[MAX_STRING];


	if (fP == NULL) {
		printf("File does not exist.");
		exit(0);
	}
	else
		// Get number of lines
		while (!feof(fP)) {
			char ch = fgetc(fP);
			if (ch == '\n')
				number++;
		}

	if (fP != NULL)
		rewind(fP);

	for (int i = 0; i < number; i++) {
		fgets(buffer, MAX_LINE, fP);


		field = strtok_s(buffer, ";", &nextToken);
		key = atoi(field);

		field = strtok_s(NULL, ";", &nextToken);
		strcpy_s(string, MAX_STRING, field);
		//replace \n in name
		string[strlen(string) - 1] = '\0';

		putAH(hashtableAH, key, string);
	}

	return;
}
