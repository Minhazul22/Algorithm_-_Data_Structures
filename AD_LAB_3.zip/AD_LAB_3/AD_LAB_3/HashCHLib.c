#include "HashCHLib.h"

int putCH(sElementCH* hashtableCH[MAX_ARRAY], int key, char value[MAX_STRING]) {
    int index = key % MAX_ARRAY;

    // Create a new element
    sElementCH* newElement = (sElementCH*)malloc(sizeof(sElementCH));
    if (newElement == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }

    newElement->key = key;
    strcpy_s(newElement->value, MAX_STRING, value);
    newElement->next = NULL;

    // Check for collision
    int collisions = 0;
    if (hashtableCH[index] != NULL) {
        // Collision: Add new element as the head of the chain
        newElement->next = hashtableCH[index];
        hashtableCH[index] = newElement;
        collisions++;
    }
    else {
        // No collision: Insert the new element
        hashtableCH[index] = newElement;
    }

    return collisions;
}

char* getCH(sElementCH* hashtableCH[MAX_ARRAY], int key) {
    int index = key % MAX_ARRAY;

    sElementCH* current = hashtableCH[index];
    while (current != NULL) {
        if (current->key == key) {
            return current->value;
        }
        current = current->next;
    }

    return NULL;  // Key not found
}

void deleteCH(sElementCH* hashtableCH[MAX_ARRAY], int key) {
    int index = key % MAX_ARRAY;

    sElementCH* current = hashtableCH[index];
    sElementCH* prev = NULL;

    while (current != NULL && current->key != key) {
        prev = current;
        current = current->next;
    }

    if (current != NULL) {
        // Key found, delete the entry
        if (prev != NULL) {
            prev->next = current->next;
        }
        else {
            hashtableCH[index] = current->next;
        }

        free(current);
    }
}

void printHashTableCH(sElementCH* hashtableCH[MAX_ARRAY]) {
    printf("Chained Hash Table:\n");
    printf("Index   Key     Value\n");

    for (int i = 0; i < MAX_ARRAY; i++) {
        printf("%-8d", i);

        sElementCH* current = hashtableCH[i];
        while (current != NULL) {
            printf("%-8d%s\n", current->key, current->value);
            current = current->next;
        }
    }

    printf("\n");
}

void readCSVCH(FILE* fP, sElementCH* hashtableCH[MAX_ARRAY]) {
    int number = 0;
    char buffer[MAX_LINE];
    char* field;
    char* nextToken = NULL;
    int key;
    char string[MAX_STRING];

    if (fP == NULL) {
        printf("File does not exist.\n");
        exit(EXIT_FAILURE);
    }

    while (!feof(fP)) {
        char ch = fgetc(fP);
        if (ch == '\n') {
            number++;
        }
    }

    rewind(fP);

    for (int i = 0; i < number; i++) {
        fgets(buffer, MAX_LINE, fP);

        field = strtok_s(buffer, ";", &nextToken);
        key = atoi(field);

        field = strtok_s(NULL, ";", &nextToken);
        strcpy_s(string, MAX_STRING, field);
        string[strlen(string) - 1] = '\0';

        putCH(hashtableCH, key, string);
    }
}
